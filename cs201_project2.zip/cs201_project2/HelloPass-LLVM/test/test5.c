void test5(int a, int b, int c, int d, int e){
    a = b * c;
    d = b;
    c = a + b;
    e = d * c;
    d = c + 5;
}
