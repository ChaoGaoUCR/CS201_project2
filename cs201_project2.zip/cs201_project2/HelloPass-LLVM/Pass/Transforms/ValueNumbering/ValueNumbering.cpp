#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Passes/PassPlugin.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/IR/PassManager.h"
#include <iostream>
#include "llvm/Support/raw_ostream.h"
#include <sstream>
#include <string>
#include <unordered_map>
using namespace std;

using namespace llvm;


namespace {




    string getOperandname(Value* val) {
      size_t regPos;
        string Operandname;
        raw_string_ostream raw_string(Operandname);
        raw_string << *val;
        string size_string = "i32";
        if((regPos = Operandname.find_first_of("%")) != string::npos){
          Operandname = Operandname.substr(regPos,2);
        }
        else if ((regPos = Operandname.find(size_string))!= string::npos) {
          Operandname = Operandname.substr(regPos+4,Operandname.size());
        }
        // errs()<<Operandname<<"\n";
        return Operandname;
    }
      string renameaddress(string word) {
        size_t dot_position;
        if ((dot_position = word.find_first_of(".")) != string::npos) {
            return word.substr(0, dot_position);
        }
        return word;
    }

void visitor(Function &F){
  std::unordered_map <string, string>value_map;
  std::unordered_map <string,size_t>op_map;

    
		string func_name = "main";
	    errs() << "ValueNumbering: " << F.getName() << "\n";
	    
	    // Comment this line
        // if (F.getName() != func_name) return;
		size_t reg_count = 0;
    size_t add = 0;
    size_t mul = 0;
    size_t sub = 0;
    size_t udiv = 0;

    // std::string operator;
    std::string operation;
    std::string result_op;
    string binary_op;
    vector <string> operator_vec; 
    size_t count = 1;
    size_t op_name = 1;
    size_t valune_name = 1;
    // bool repeat = false;


        for (auto& basic_block : F)
        {
            for (auto& inst : basic_block)
            {
                // errs() << inst << "\n";
                string inst_in = inst.getName();
                // errs()<<inst_in<<"\n";
                if(inst.getOpcode() == Instruction::Load){
                    // errs() << "This is Load"<<"\n";
                    // errs() << "Load: " << inst.getOperand(0)->getName()<<"\n";
                string loadFromOp = renameaddress(inst.getOperand(0)->getName());
                    //  errs() << "----------Load---------------"<<"\n";
                
                // errs()<<loadFromOp<<"\n";
                string reg_name = "%"+std::to_string(reg_count);
                // errs()<<reg_name<<"\n";
                reg_count++;
                op_map[reg_name] = op_map[loadFromOp];
                errs()<<inst<<"\t"<<op_map[reg_name]<<" = "<<op_map[reg_name]<<"\n";
                // errs()<<"register rename\t"<< reg_name<< "\t" <<op_map[reg_name]<<"\n";           
                }
                if(inst.getOpcode() == Instruction::Store){
                    // errs() << "This is Store"<<"\n";
                    //  errs() << "----------Store---------------"<<"\n";

                    string storeSrc = inst.getOperand(0)->getName();
                    //if constant, has no name
                    if (storeSrc == "") {
                      
                        storeSrc= getOperandname(inst.getOperand(0));
                    }
                    else{
                      // errs()<<"not blanck for storeSrc"<<"\n";
                    }

                    //storeDest is always a variable (never a constant)
                    string storeDest = renameaddress(inst.getOperand(1)->getName());
                    // errs()<<storeSrc<<"\n";
                    // errs()<<storeDest<<"\n";

                    if(storeSrc==storeDest){
                          op_map[storeSrc] = op_name;
                          op_name++;                      
                    }
                    else{
                      if (op_map.find(storeSrc) == op_map.end())
                          {
                            op_map[storeSrc] = op_name;
                            op_map[storeDest] = op_name;

                            op_name++;
                            
                          }
                      else
                          {
                            op_map[storeDest] = op_map[storeSrc];
                          }  
                    }
                    errs()<<inst<<"\t"<<op_map[storeDest]<<" = "<<op_map[storeSrc]<<"\n";
                      // errs() << storeSrc << "\t"<<op_map[storeSrc]<<"\n";
                      // errs() << storeDest << "\t"<<op_map[storeDest]<<"\n";

               

                    // errs() << "Store: "<< inst.getOperand(0)->getName()<<"\n";

                    // errs() << "Store: "<< inst.getOperand(1)->getName()<<"\n";
                }
                if (inst.isBinaryOp())
                {
                    // errs() << "Op Code:" << inst.getOpcodeName()<<"\n";
                    //  errs() <<"--------"<<inst.getOpcodeName()<<"--------"<<"\n";
                      // size_t count = 1;
                      // vector <string> operator_vec;  
                    bool repeat = false;
                                    
                    operation = inst.getOpcodeName();
                    // auto item=operator_vec.begin();
                    // std::vector<string>::iterator item;
                    //  errs() <<"--------"<<operation<<"--------"<<"\n";
                    
                    if ( std::find(operator_vec.begin(), operator_vec.end(), operation) != operator_vec.end() ){
                      result_op = operation+to_string(count);
                      count++;

                    }
                      // do_this();
                    else{
                      operator_vec.push_back(operation);
                      result_op = operation;
                      // errs()<<operator_vec[0]<<"\n";
                      // errs() << "First time "<<operation<<"\n";
                    }
                    //  errs() <<"result op \t"<< result_op<<"\n";



                    string op0 = inst.getOperand(0)->getName();
                    //if constant, has no name
                    if (op0 == "") {
                      
                        op0= getOperandname(inst.getOperand(0));
                    }
                    else{
                      // errs()<<"not blanck for op0"<<"\n";
                    }

                    //storeDest is always a variable (never a constant)
                    string op1 = renameaddress(inst.getOperand(1)->getName());
                    if (op1 == "") {
                      
                        op1= getOperandname(inst.getOperand(1));
                    }
                    else{
                      // errs()<<"not blanck for op1"<<"\n";
                    }


                    //rename op0,op1
                      if (op_map.find(op0) == op_map.end())
                          {
                            op_map[op0] = op_name;
                            // op_map[storeDest] = op_name;

                            op_name++;
                            
                          }
                      if (op_map.find(op1) == op_map.end())
                          {
                            op_map[op1] = op_name;
                            // op_map[storeDest] = op_name;

                            op_name++;
                            
                          }                     




                    // errs()<<op0<<"\t"<< op_map[op0]<<"\n";
                    // errs()<<op1<<"\t"<< op_map[op1]<<"\n";
                    binary_op = to_string(op_map[op0])+operation+to_string(op_map[op1]);
                    // errs()<<binary_op<<"\n";
                      if (value_map.find(binary_op) == value_map.end())
                          {
                            value_map[binary_op] = result_op;
                            // op_map[storeDest] = op_name;
                            op_map[result_op] = op_name;
                            op_name++;

                            // valune_name++;
                            
                          }
                      else
                          {
                            // value_map[binary_op] = op_map[storeSrc];
                            op_map[result_op] = op_map[value_map[binary_op]];
                            repeat = true;
                            // errs()<<"redundant"<<"\n";

                          }                      
                        // errs()<<result_op<<"\t"<<op_map[result_op]<<"\n";
                        errs()<<inst<< "\t"<<op_map[result_op]<<" = "<< to_string(op_map[op0])+ " " + operation+ " " +to_string(op_map[op1]);
                        if(repeat){
                          errs()<<"\t"<<"(redundant)"<<"\n";
                        }
                        else{
                          errs()<<"\n";
                        }
                    

                } // end if
            } // end for inst
        } // end for block
        
}


// New PM implementation
struct ValueNumberingPass : public PassInfoMixin<ValueNumberingPass> {

  // The first argument of the run() function defines on what level
  // of granularity your pass will run (e.g. Module, Function).
  // The second argument is the corresponding AnalysisManager
  // (e.g ModuleAnalysisManager, FunctionAnalysisManager)
  PreservedAnalyses run(Function &F, FunctionAnalysisManager &) {
  	visitor(F);
	return PreservedAnalyses::all();

	
  }
  
    static bool isRequired() { return true; }
};
}



//-----------------------------------------------------------------------------
// New PM Registration
//-----------------------------------------------------------------------------
extern "C" ::llvm::PassPluginLibraryInfo LLVM_ATTRIBUTE_WEAK
llvmGetPassPluginInfo() {
  return {
    LLVM_PLUGIN_API_VERSION, "ValueNumberingPass", LLVM_VERSION_STRING,
    [](PassBuilder &PB) {
      PB.registerPipelineParsingCallback(
        [](StringRef Name, FunctionPassManager &FPM,
        ArrayRef<PassBuilder::PipelineElement>) {
          if(Name == "value-numbering"){
            FPM.addPass(ValueNumberingPass());
            return true;
          }
          return false;
        });
    }};
}
